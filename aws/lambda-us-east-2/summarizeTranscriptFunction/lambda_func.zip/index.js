import axios from 'axios';

export const handler = async (event) => {
    try {
        // Make an HTTP GET request using axios
        const response = await axios.get('https://api.example.com/data');
        
        // Log the response data
        console.log('Data from API:', response.data);
        
        // Create a response message
        const responseMessage = {
            message: 'Request to external API was successful!',
            data: response.data
        };
        
        // Return a successful response
        return {
            statusCode: 200,
            body: JSON.stringify(responseMessage),
        };
    } catch (error) {
        // Handle any errors and return a 500 response
        console.error('Error making request:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'An error occurred.' }),
        };
    }
};
